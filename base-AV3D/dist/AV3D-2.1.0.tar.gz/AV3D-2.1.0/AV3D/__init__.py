from Area2D import areaTriangulo
from Area2D import areaCudrado
from Area2D import areaRectangulo
from Area2D import areaRombo
from Area2D import areaRomboide
from Area2D import areaTrapecio
from Area2D import areaCirculo
from Area2D import areaPoligonoRegular
from Volume3D import volumenCubo
from Volume3D import volmenPrisma
from Volume3D import volumenPiramide
from Volume3D import volumenCilindro
from Volume3D import volumenCono
from Volume3D import volumenEsfera
import math
